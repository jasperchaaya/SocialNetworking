# COMP4602

Mesa 1.2.1 was developed and tested with older versions of Python (Python 3.7 – 3.10)


installations (put this line in your terminal):
pip install mesa==1.2.1 networkx


ensure these 4 files are in the same directory:
agent.py
model.py
server.py
run.py


run the simulation from the terminal using:
python run.py